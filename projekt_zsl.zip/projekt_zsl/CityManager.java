package projekt_zsl;

import java.util.ArrayList;
import java.util.List;

public class CityManager {
		private List<City> citys;
		private CityDBLayer citysDB;
		
		public CityManager () {
			citysDB = new CityDBLayer();
			citys = new ArrayList<City>();
		}
		
		public void addCity (City c) throws Exception {
			citysDB.addCity(c);
			citys.add(c);
		}
		
		public Boolean removeCity (int cityId) throws Exception {
			City tempCity = null;
			for (City c : citys)
				if (c.getId()==(cityId)) {
					tempCity = c;
					break;
				}
			if (tempCity != null) {
				removeCity(tempCity);
				return true;
			}
			else
				return false;
		}
		
		public void removeCity (City c) throws Exception {
			citysDB.removeCity(c);
			citys.remove(c);
		}
		
		public List<City> readCitys() throws Exception {
			this.citys = citysDB.getCitys();
			return this.citys;
		}
		
		public List<City> getCitys() throws Exception {
			if (this.citys == null || this.citys.size() == 0)
				this.citys = citysDB.getCitys();
			return this.citys;
		}
		
		public City getCity (int id) {
			for (City c : citys)
				if (c.getId()==(id)) {
					return c;
				}
			return null;
		}


	}