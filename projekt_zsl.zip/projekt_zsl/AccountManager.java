package projekt_zsl;

import java.util.Scanner;

public class AccountManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonManager oc = new PersonManager();
		CityManager cm = new CityManager(); 
		oc.setCitys(cm);
		
		Scanner scan = new Scanner (System.in);
		Boolean cont = true;
		do {
			System.out.println("Podaj operacje:");
			System.out.println("[1]. Dodanie osoby");
			System.out.println("[2]. Usuni�cie osoby");
			System.out.println("[3]. Dodaj miasto");
			System.out.println("[4]. Usu� miasto");
			System.out.println("[5]. Wyswietlenie os�b");
			System.out.println("[6]. Wyswietlenie miast");
			System.out.println("[7]. Koniec dzia�ania aplikacji");
			String operation = scan.nextLine();
			if ("1".equals(operation)) {
				System.out.println("Podaj imie");
				String name = scan.nextLine();
				System.out.println("Podaj nazwisko");
				String secondName = scan.nextLine();
				System.out.println("Podaj adres");
				String address = scan.nextLine();
				System.out.println("Podaj miasto");
				System.out.println("Lista Miast:");
					try {
						for(City c : cm.getCitys())
							System.out.println(c.getName() + "-" + c.getId());
					} catch (Exception e) {
						System.out.println("B��d w trakcie wy�wierlania listy miast: " + e);
						e.printStackTrace();
					}
				int cityAdd = scan.nextInt();
				City c = cm.getCity(cityAdd);
				Person p1 = new Person();
				p1.setFirstName(name);
				p1.setLastName(secondName);
				p1.setAddress(address);
				p1.setCity(c);
				try {
					oc.addPerson(p1);
				} catch (Exception e) {
					System.out.println("B��d w trakcie dodawania osoby: " + e);
					e.printStackTrace();
				}
			} else if ("2".equals(operation)) {
				System.out.println("Podaj nazw�");
				int personsID = scan.nextInt();
				try {
					if (!oc.removePerson(personsID))
						System.out.println("Osoby nie ma na li�cie");
					else
						System.out.println("Usuni�to osoby z listy");
				} catch (Exception e) {
					System.out.println("B��d w trakcie usuwania osoby: " + e);
					e.printStackTrace();
				}
			} else if ("3".equals(operation)) {
				System.out.println("Wpisz nazwe miasta");
				String nameCity = scan.nextLine();
				System.out.println("Podaj idyfikator miasta:");
				int id = scan.nextInt();
				scan.nextLine();
				City c1 = new City();
				c1.setName(nameCity);
				c1.setId(id);
				try {
					cm.addCity(c1);
				} catch (Exception e) {
					System.out.println("B��d w trakcie dodawania miasta: " + e);
					e.printStackTrace();
				}
				} else if ("4".equals(operation)) {
				System.out.println("Jakie miasto chesz usun��?");
				System.out.println("Lista Miast:");
				try {
					for(City c : cm.getCitys()) {
						System.out.println(c.getName() + "-" + c.getId());
					}
				} catch (Exception e) {
					System.out.println("B��d w trakcie wy�wierlania listy miast: " + e);
					e.printStackTrace();
				}
				int cityId = scan.nextInt();
				scan.nextLine();
				try {
					if (!cm.removeCity(cityId))
						System.out.println("Miasta nie ma na li�cie");
					else
						System.out.println("Usuni�to miasto z listy");
				} catch (Exception e) {
					System.out.println("B��d w trakcie usuwania miasta: " + e);
					e.printStackTrace();
				}
				}else if ("5".equals(operation)) {
				System.out.println("Lista os�b:");
				try {
					for (Person p : oc.getPersons()) {
						System.out.println(p);
					}
				} catch (Exception e) {
					System.out.println("B��d w trakcie wy�wietlania listy os�b: " + e);
					e.printStackTrace();
					}
				} else if ("6".equals(operation)) {
					System.out.println("Lista Miast:");
					try {
						for(City c : cm.getCitys()) {
							System.out.println(c.getName() + "-" + c.getId());
						}
					} catch (Exception e) {
						System.out.println("B��d w trakcie wy�wierlania listy miast: " + e);
						e.printStackTrace();
					}
				} else if ("7".equals(operation)) {
				System.out.println("Bye.");
				cont = false;
			} else {
				System.out.println("Nieprawid�owa operacja");
			}
		} while (cont);
		scan.close();
	}
}