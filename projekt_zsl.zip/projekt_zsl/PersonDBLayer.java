package projekt_zsl;

import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PersonDBLayer {
	public void addPerson(Person prsn) throws Exception {
		Connection connection = null;
		try {
			Class.forName("org.sqlite.JDBC");
        	connection = DriverManager.getConnection("jdbc:sqlite:D:/DB/Baza Danych.db");

        	Statement statement = connection.createStatement();
        	statement.setQueryTimeout(30); 

        	String sql = "INSERT INTO Persons (FirstName,LastName,Address,CityID) values(?,?,?,?)";
        	
    		PreparedStatement pstmt = connection.prepareStatement(sql);
    		pstmt.setString(1,prsn.getFirstName());
    		pstmt.setString(2,prsn.getLastName());
    		pstmt.setString(3,prsn.getAddress());
    		//pstmt.setInt(4,prsn.getCity());
    		pstmt.executeUpdate();

	        
		}
	    	catch(SQLException e){
	    	 	System.err.println(e.getMessage());
	    	 	throw e;
	    	}
		catch (ClassNotFoundException e) {
			System.err.println(e.getMessage()); 
			throw e;
		}
	    	finally {         
			try {
				if(connection != null)
					connection.close();
			}
			catch(SQLException e) {          
				System.err.println(e); 
			}
	    }
	}
	
	public void removePerson (Person prsn) throws Exception {
		Connection connection = null;
		try {
			Class.forName("org.sqlite.JDBC");
	        	connection = DriverManager.getConnection("jdbc:sqlite:D:/DB/Baza Danych.db");

	        	Statement statement = connection.createStatement();
	        	statement.setQueryTimeout(30); 

	        	statement.executeUpdate("DELETE FROM Persons WHERE name='"+ prsn.getId() + "'");
	        
		}
	    	catch(SQLException e){
	    	 	System.err.println(e.getMessage());
	    	 	throw e;
	    	}
		catch (ClassNotFoundException e) {
			System.err.println(e.getMessage()); 
			throw e;
		}
	    	finally {         
			try {
				if(connection != null)
					connection.close();
			}
			catch(SQLException e) {          
				System.err.println(e); 
			}
	    }
	}
	
	public List<Person> getPersons () throws Exception {
		List<Person> listOfPersons = new ArrayList<Person>();

		Connection connection = null;
		try {
			Class.forName("org.sqlite.JDBC");
	         	connection = DriverManager.getConnection("jdbc:sqlite:D:/DB/Baza Danych.db");

	         	Statement statement = connection.createStatement();
	         	statement.setQueryTimeout(30); 

	         	ResultSet resultSet = statement.executeQuery("SELECT PersonID, FirstName, LastName, Address, Person.City");
	         	while(resultSet.next())
	         	{
	        	 	Person newPerson = new Person();
	        	 	newPerson.setId(resultSet.getInt("PersonID"));
	        	 	newPerson.setFirstName(resultSet.getString("FirstName"));
	        	 	newPerson.setLastName(resultSet.getString("LastName"));
	        	 	newPerson.setAddress(resultSet.getString("Address"));
	        	 	//newPerson.setCity(resultSet.getCity("City"));
	        	 	
	        	 	listOfPersons.add (newPerson);
	         	}
		}
	    	catch(SQLException e){
	    	 	System.err.println(e.getMessage()); 
	    	}       
	    	finally {         
			try {
				if(connection != null)
					connection.close();
			}
			catch(SQLException e) {        
				System.err.println(e); 
			}
	    	}
		
		return listOfPersons;
	}
}