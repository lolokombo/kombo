package projekt_zsl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CityDBLayer {
	public void addCity(City ccit) throws Exception {
		Connection connection = null;
		try {
			Class.forName("org.sqlite.JDBC");
	        	connection = DriverManager.getConnection("jdbc:sqlite:D:/DB/Baza Danych.db");

	        	Statement statement = connection.createStatement();
	        	statement.setQueryTimeout(30); 
	        	
	        	String sql ="INSERT INTO City(CityId,CityName) values(?,?)";
	        	PreparedStatement pstmt = connection.prepareStatement(sql);
	        	pstmt.setInt(1,ccit.getId());
	        	pstmt.setString(2,ccit.getName());
	        	pstmt.executeUpdate();
		}
    	catch(SQLException e){
    	 	System.err.println(e.getMessage());
    	 	throw e;
    	}
	catch (ClassNotFoundException e) {
		System.err.println(e.getMessage()); 
		throw e;
	}
    	finally {         
		try {
			if(connection != null)
				connection.close();
		}
		catch(SQLException e) {          
			System.err.println(e); 
		}
    }
}
	public void removeCity (City ccti) throws Exception {
		Connection connection = null;
		try {
			Class.forName("org.sqlite.JDBC");
	        	connection = DriverManager.getConnection("jdbc:sqlite:D:/DB/Baza Danych.db");

	        	Statement statement = connection.createStatement();
	        	statement.setQueryTimeout(30); 	    
	        	
	        	statement.executeUpdate("DELETE FROM City WHERE CityId='" + ccti.getId() + "'");
		}
	    	catch(SQLException e){
	    	 	System.err.println(e.getMessage());
	    	 	throw e;
	    	}
		catch (ClassNotFoundException e) {
			System.err.println(e.getMessage()); 
			throw e;
		}
	    	finally {         
			try {
				if(connection != null)
					connection.close();
			}
			catch(SQLException e) {          
				System.err.println(e); 
			}
	    }
	}
	public List<City> getCitys () throws Exception {
		List<City> listOfCitys = new ArrayList<City>();

		Connection connection = null;
		try {
			Class.forName("org.sqlite.JDBC");
	         	connection = DriverManager.getConnection("jdbc:sqlite:D:/DB/Baza Danych.db");

	         	Statement statement = connection.createStatement();
	         	statement.setQueryTimeout(30); 

	         	ResultSet resultSet = statement.executeQuery("SELECT CityName,CityId FROM City ");
	         	while(resultSet.next())
	         	{
	         		City personCity = new City();
	         		personCity.setId(resultSet.getInt("CityId"));
	         		personCity.setName(resultSet.getString("CityName"));
	         		listOfCitys.add(personCity);

	         	}
			}
			catch(SQLException e){
			 	System.err.println(e.getMessage()); 
			}       
			finally {         
			try {
				if(connection != null)
					connection.close();
			}
			catch(SQLException e) {        
				System.err.println(e); 
			}
			}
		
		return listOfCitys;

	}
}


