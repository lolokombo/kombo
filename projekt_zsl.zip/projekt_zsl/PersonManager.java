package projekt_zsl;

import java.util.ArrayList;
import java.util.List;

public class PersonManager {
	private List<Person> persons;
	private PersonDBLayer personsDB;
	private CityManager citys;
	
	
	
	public CityManager getCitys() {
		return citys;
	}

	public void setCitys(CityManager citys) {
		this.citys = citys;
	}

	public PersonManager () {
		personsDB = new PersonDBLayer();
		persons = new ArrayList<Person>();
	}
	
	public void addPerson (Person p) throws Exception {
		personsDB.addPerson(p);
		persons.add(p);
	}
	
	public Boolean removePerson (int id) throws Exception {
		Person tempPerson = null;
		for (Person p : persons)
			if (p.getId()==(id)) {
				tempPerson = p;
				break;
			}
		if (tempPerson != null) {
			removePerson(tempPerson);
			return true;
		}
		else
			return false;
	}
	
	public void removePerson (Person p) throws Exception {
		personsDB.removePerson(p);
		persons.remove(p);
	}
	
	public List<Person> readPersons() throws Exception {
		this.persons = personsDB.getPersons();
		return this.persons;
	}
	
	public List<Person> getPersons() throws Exception {
		if (this.persons == null || this.persons.size() == 0)
			this.persons = personsDB.getPersons();
		return this.persons;
	}
	
	public Person getPerson (String name) {
		/*for (Person p : persons)
			if (p.getName().equals(name)) {
				return p;
			}*/
		return null;
	}


}